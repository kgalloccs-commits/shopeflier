# Shopeflier App - Process Flow & Features

## 📱 Application Overview
Shopeflier is a fully functional marketplace application where users can buy and sell items locally.

## 🔄 Complete Process Flow

### 1. App Launch & Authentication
```
App Start
    ↓
Check Login Status
    ↓
┌─────────────┴─────────────┐
│                           │
Not Logged In          Logged In
    ↓                       ↓
MainActivity           DashboardActivity
(Login/Register)
```

### 2. MainActivity (Authentication Screen)
**Features:**
- Toggle between Login and Registration modes
- **Login Mode:**
  - Email input
  - Password input
  - Form validation
  - Auto-navigate to Dashboard on success

- **Registration Mode:**
  - Full name input
  - Email input
  - Phone number input
  - Password input
  - Confirm password input
  - Comprehensive validation
  - Auto-login after successful registration

**Data Storage:**
- User data stored in SharedPreferences
- Password stored (in production, should be hashed)
- Session management with login status

### 3. DashboardActivity (Main Hub)
**Features:**
- Bottom navigation with 5 tabs
- User greeting with name
- Logout functionality
- Fragment container for dynamic content

**Navigation Tabs:**
1. 🏠 Home
2. 🔍 Browse
3. 💰 Sell
4. 💬 Messages
5. 👤 Profile

---

## 📋 Feature Details

### 🏠 Home Fragment
**Purpose:** Dashboard overview and quick actions

**Features:**
- Personalized welcome message
- Quick stats display:
  - Items listed count
  - Transactions count
  - Messages count
- Quick action buttons:
  - Browse Products
  - Sell Item
- Sample product listings

**Data Displayed:**
- User's active listings count
- Featured products
- Recent listings

---

### 🔍 Browse Fragment
**Purpose:** Search and discover products

**Features:**
- Search functionality
  - Real-time product search
  - Search by title, description, or category
- Category filters:
  - All Products
  - Electronics
  - Furniture
  - Fashion
  - And more...
- Product cards showing:
  - Product title
  - Price
  - Description
  - Condition
  - Category
  - Location
  - Seller name
- Result count display
- Tap to view product details

**Categories Available:**
- Electronics
- Furniture
- Fashion
- Sports
- Books
- Home & Garden
- Toys & Games
- Automotive
- Other

---

### 💰 Sell Fragment
**Purpose:** List new items for sale

**Features:**
- Product listing form:
  - Product name
  - Price (validated for positive numbers)
  - Description
  - Category selection (dropdown)
  - Condition selection (dropdown)
  - Location
- Photo upload button (placeholder)
- Form validation:
  - All fields required
  - Price must be valid number
  - Category must be selected
  - Condition must be selected
- Auto-save to product database
- Success confirmation
- Form auto-clear after submission

**Condition Options:**
- New
- Like New
- Good
- Fair

**Data Saved:**
- Product details
- Seller information (from current user)
- Timestamp
- Unique product ID

---

### 💬 Messages Fragment
**Purpose:** Chat with buyers and sellers

**Features:**
- Conversation list
- Empty state message
- Sample conversation (demonstration)
- Message cards showing:
  - User name
  - Last message
  - Timestamp
  - Unread count

**Future Enhancements:**
- Real-time messaging
- Product-specific conversations
- Message notifications
- Read/unread status

---

### 👤 Profile Fragment
**Purpose:** User account management and listings

**Features:**
- User information display:
  - Name
  - Email
  - Phone number
  - Member since date
  - Total listings count
- My Listings section:
  - All user's active products
  - Product cards with:
    - Title
    - Price
    - Condition
    - Delete button
- Edit Profile button (placeholder)
- Logout button with confirmation

**Actions:**
- View all personal listings
- Delete listings
- Logout (clears session, returns to login)

---

## 💾 Data Management

### UserManager
**Responsibilities:**
- User registration
- User login/authentication
- Session management
- Current user retrieval
- Logout functionality

**Storage:**
- SharedPreferences
- JSON serialization with Gson
- Persistent user data

### ProductManager
**Responsibilities:**
- Add new products
- Retrieve all products
- Get featured products
- Filter by category
- Search products
- Get seller's products
- Delete products
- Sample data initialization

**Storage:**
- SharedPreferences
- JSON serialization with Gson
- Persistent product data

---

## 🎨 User Experience Flow

### First Time User Journey
```
1. Open App
2. See Login Screen
3. Tap "Don't have an account? Register"
4. Fill registration form
5. Submit
6. Auto-login → Dashboard
7. See Home screen with welcome message
8. Browse sample products
9. List first item via Sell tab
10. View listing in Profile tab
```

### Returning User Journey
```
1. Open App
2. Auto-login (if previously logged in)
3. Dashboard → Home screen
4. Browse products
5. Search for items
6. List new items
7. Manage existing listings
8. Logout when done
```

---

## 🔐 Security Features
- Email validation
- Password length validation (minimum 6 characters)
- Password confirmation matching
- Phone number validation
- Session management
- Logout clears all session data

---

## 📊 Sample Data
The app includes 5 sample products on first launch:
1. iPhone 13 Pro - $899.99 (Electronics, Featured)
2. MacBook Air M2 - $1,199.99 (Electronics, Featured)
3. Vintage Leather Sofa - $450.00 (Furniture)
4. Mountain Bike - $650.00 (Sports, Featured)
5. Designer Handbag - $180.00 (Fashion)

---

## 🚀 Technical Implementation

### Architecture
- **Pattern:** MVVM-inspired with Fragments
- **Navigation:** Bottom Navigation View
- **Data Binding:** View Binding
- **Storage:** SharedPreferences with Gson
- **Language:** Kotlin

### Key Components
1. **Activities:**
   - MainActivity (Authentication)
   - DashboardActivity (Main Hub)

2. **Fragments:**
   - HomeFragment
   - BrowseFragment
   - SellFragment
   - MessagesFragment
   - ProfileFragment

3. **Models:**
   - User
   - Product
   - Message
   - Conversation

4. **Utilities:**
   - UserManager
   - ProductManager

### Dependencies
- AndroidX Core KTX
- AppCompat
- Material Design Components
- ConstraintLayout
- Navigation Components
- Lifecycle Components
- Fragment KTX
- Gson (JSON serialization)

---

## 🎯 App Capabilities

### ✅ Fully Functional Features
- User registration and login
- Session persistence
- Product listing creation
- Product browsing and search
- Category filtering
- User profile management
- Listing management (view/delete)
- Logout functionality

### 🔄 Placeholder Features (Future Enhancement)
- Photo upload
- Real-time messaging
- Payment integration
- Rating system
- Location-based search
- Push notifications
- Product editing
- Transaction history

---

## 📱 User Interface
- Clean, modern Material Design
- Card-based layouts
- Intuitive navigation
- Responsive forms
- Error handling with user feedback
- Toast notifications for actions
- Empty states with helpful messages

---

## 🎉 Success Criteria
✅ App builds and runs successfully
✅ User can register and login
✅ User can browse products
✅ User can list new products
✅ User can search and filter products
✅ User can view and manage their listings
✅ User can logout
✅ Data persists across app sessions
✅ Meets Google Play API level 34 requirement

---

## 🔮 Future Enhancements
1. Image upload and display
2. Real-time chat functionality
3. Push notifications
4. Payment gateway integration
5. User ratings and reviews
6. Advanced search filters
7. Favorites/Wishlist
8. Product sharing
9. Location-based recommendations
10. Analytics dashboard
