package com.shopeflier.app.models

data class Product(
    val id: String,
    val title: String,
    val description: String,
    val price: Double,
    val category: String,
    val condition: String, // New, Like New, Good, Fair
    val imageUrl: String?,
    val sellerEmail: String,
    val sellerName: String,
    val location: String,
    val postedDate: Long,
    val isFeatured: Boolean = false,
    val views: Int = 0
)
