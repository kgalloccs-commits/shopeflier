package com.shopeflier.app.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.shopeflier.app.MainActivity
import com.shopeflier.app.databinding.FragmentProfileBinding
import com.shopeflier.app.utils.ProductManager
import com.shopeflier.app.utils.UserManager

class ProfileFragment : Fragment() {
    
    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!
    private lateinit var userManager: UserManager
    private lateinit var productManager: ProductManager
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        userManager = UserManager(requireContext())
        productManager = ProductManager(requireContext())
        setupUI()
    }
    
    override fun onResume() {
        super.onResume()
        // Refresh UI when returning from edit
        setupUI()
    }
    
    private fun setupUI() {
        val currentUser = userManager.getCurrentUser()
        
        currentUser?.let { user ->
            binding.tvName.text = user.name
            binding.tvEmail.text = user.email
            binding.tvPhone.text = user.phone
            binding.tvMemberSince.text = formatDate(user.registrationDate)
            
            loadUserListings(user.email)
        }
        
        binding.btnEditProfile.setOnClickListener {
            val intent = Intent(requireContext(), com.shopeflier.app.EditProfileActivity::class.java)
            startActivity(intent)
        }
    }
    
    private fun loadUserListings(userEmail: String) {
        val userProducts = productManager.getProductsBySeller(userEmail)
        
        if (userProducts.isEmpty()) {
            Toast.makeText(requireContext(), "No listings yet. Start selling to see your items here!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(requireContext(), "You have ${userProducts.size} active listings", Toast.LENGTH_SHORT).show()
            
            // Show detailed listing information
            val listingDetails = StringBuilder()
            listingDetails.append("Your Listings:\n\n")
            
            userProducts.forEachIndexed { index, product ->
                listingDetails.append("${index + 1}. ${product.title}\n")
                listingDetails.append("   Price: $${String.format("%.2f", product.price)}\n")
                listingDetails.append("   Category: ${product.category}\n")
                listingDetails.append("   Condition: ${product.condition}\n")
                if (product.imageUrl != null) {
                    listingDetails.append("   📷 Has photo\n")
                }
                listingDetails.append("   Posted: ${formatDate(product.postedDate)}\n\n")
            }
            
            // Create a dialog to show detailed listings
            android.app.AlertDialog.Builder(requireContext())
                .setTitle("My Listings (${userProducts.size})")
                .setMessage(listingDetails.toString())
                .setPositiveButton("OK", null)
                .setNeutralButton("Add New Item") { _, _ ->
                    // Navigate to Sell tab
                    (activity as? com.shopeflier.app.DashboardActivity)?.let { dashboardActivity ->
                        dashboardActivity.findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(
                            com.shopeflier.app.R.id.bottom_navigation
                        )?.selectedItemId = com.shopeflier.app.R.id.nav_sell
                    }
                }
                .show()
        }
    }
    
    private fun formatDate(timestamp: Long): String {
        val date = java.util.Date(timestamp)
        val format = java.text.SimpleDateFormat("MMM yyyy", java.util.Locale.getDefault())
        return format.format(date)
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
