package com.shopeflier.app.fragments

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import com.shopeflier.app.databinding.FragmentSellBinding
import com.shopeflier.app.models.Product
import com.shopeflier.app.utils.ProductManager
import com.shopeflier.app.utils.UserManager
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID

class SellFragment : Fragment() {
    
    private var _binding: FragmentSellBinding? = null
    private val binding get() = _binding!!
    private lateinit var productManager: ProductManager
    private lateinit var userManager: UserManager
    private var selectedImageUri: Uri? = null
    private var selectedImageBase64: String? = null
    private var photoFile: File? = null
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSellBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    // Activity result launchers
    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                selectedImageUri = uri
                convertImageToBase64(uri)
                showImagePreview(uri)
            }
        }
    }
    
    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            photoFile?.let { file ->
                val uri = Uri.fromFile(file)
                selectedImageUri = uri
                convertImageToBase64(uri)
                showImagePreview(uri)
            }
        }
    }
    
    private val cameraPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        if (isGranted) {
            openCamera()
        } else {
            Toast.makeText(requireContext(), "Camera permission is required to take photos", Toast.LENGTH_SHORT).show()
        }
    }
    
    private val storagePermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        if (isGranted) {
            openGallery()
        } else {
            Toast.makeText(requireContext(), "Storage permission is required to select photos", Toast.LENGTH_SHORT).show()
        }
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        productManager = ProductManager(requireContext())
        userManager = UserManager(requireContext())
        setupUI()
    }
    
    private fun setupUI() {
        binding.btnListItem.setOnClickListener {
            handleListItem()
        }
        
        binding.btnAddPhoto.setOnClickListener {
            showPhotoOptionsDialog()
        }
    }
    
    private fun showPhotoOptionsDialog() {
        val options = arrayOf("Take Photo", "Choose from Gallery", "Cancel")
        
        AlertDialog.Builder(requireContext())
            .setTitle("Add Photo")
            .setItems(options) { dialog, which ->
                when (which) {
                    0 -> checkCameraPermissionAndOpen()
                    1 -> checkStoragePermissionAndOpen()
                    2 -> dialog.dismiss()
                }
            }
            .show()
    }
    
    private fun checkCameraPermissionAndOpen() {
        when {
            ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED -> {
                openCamera()
            }
            else -> {
                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }
    }
    
    private fun checkStoragePermissionAndOpen() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            // Android 13+ doesn't need READ_EXTERNAL_STORAGE permission for gallery
            openGallery()
        } else {
            when {
                ContextCompat.checkSelfPermission(
                    requireContext(),
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED -> {
                    openGallery()
                }
                else -> {
                    storagePermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                }
            }
        }
    }
    
    private fun openCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        photoFile = createImageFile()
        photoFile?.let { file ->
            val photoUri = FileProvider.getUriForFile(
                requireContext(),
                "${requireContext().packageName}.fileprovider",
                file
            )
            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri)
            cameraLauncher.launch(intent)
        }
    }
    
    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        galleryLauncher.launch(intent)
    }
    
    private fun createImageFile(): File {
        val timeStamp = System.currentTimeMillis()
        val storageDir = requireContext().getExternalFilesDir(null)
        return File.createTempFile(
            "JPEG_${timeStamp}_",
            ".jpg",
            storageDir
        )
    }
    
    private fun convertImageToBase64(uri: Uri) {
        try {
            val inputStream = requireContext().contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            
            // Resize bitmap to reduce size
            val resizedBitmap = resizeBitmap(bitmap, 800, 800)
            
            val byteArrayOutputStream = ByteArrayOutputStream()
            resizedBitmap.compress(Bitmap.CompressFormat.JPEG, 80, byteArrayOutputStream)
            val byteArray = byteArrayOutputStream.toByteArray()
            selectedImageBase64 = Base64.encodeToString(byteArray, Base64.DEFAULT)
            
            inputStream?.close()
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "Error processing image: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun resizeBitmap(bitmap: Bitmap, maxWidth: Int, maxHeight: Int): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        
        val ratioBitmap = width.toFloat() / height.toFloat()
        val ratioMax = maxWidth.toFloat() / maxHeight.toFloat()
        
        var finalWidth = maxWidth
        var finalHeight = maxHeight
        
        if (ratioMax > ratioBitmap) {
            finalWidth = (maxHeight.toFloat() * ratioBitmap).toInt()
        } else {
            finalHeight = (maxWidth.toFloat() / ratioBitmap).toInt()
        }
        
        return Bitmap.createScaledBitmap(bitmap, finalWidth, finalHeight, true)
    }
    
    private fun showImagePreview(uri: Uri) {
        try {
            // Update button text to show image is selected
            binding.btnAddPhoto.text = "✓ Photo Added"
            binding.btnAddPhoto.setBackgroundColor(
                ContextCompat.getColor(requireContext(), android.R.color.holo_green_light)
            )
            
            Toast.makeText(requireContext(), "Photo added successfully!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "Error displaying image", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun handleListItem() {
        val productName = binding.etProductName.text.toString().trim()
        val price = binding.etPrice.text.toString().trim()
        val description = binding.etDescription.text.toString().trim()
        val category = binding.spinnerCategory.selectedItem.toString()
        
        if (validateInput(productName, price, description, category)) {
            val currentUser = userManager.getCurrentUser()
            if (currentUser != null) {
                val product = Product(
                    id = UUID.randomUUID().toString(),
                    title = productName,
                    description = description,
                    price = price.toDouble(),
                    category = category,
                    condition = "Good",
                    imageUrl = selectedImageBase64, // Save the base64 encoded image
                    sellerEmail = currentUser.email,
                    sellerName = currentUser.name,
                    location = "Not specified",
                    postedDate = System.currentTimeMillis(),
                    isFeatured = false
                )
                
                productManager.addProduct(product)
                Toast.makeText(requireContext(), "Item listed successfully!", Toast.LENGTH_SHORT).show()
                clearForm()
            }
        }
    }
    
    private fun validateInput(name: String, price: String, description: String, category: String): Boolean {
        when {
            name.isEmpty() -> {
                binding.etProductName.error = "Product name is required"
                return false
            }
            price.isEmpty() -> {
                binding.etPrice.error = "Price is required"
                return false
            }
            price.toDoubleOrNull() == null || price.toDouble() <= 0 -> {
                binding.etPrice.error = "Please enter a valid price"
                return false
            }
            description.isEmpty() -> {
                binding.etDescription.error = "Description is required"
                return false
            }
            category == "Select Category" -> {
                Toast.makeText(requireContext(), "Please select a category", Toast.LENGTH_SHORT).show()
                return false
            }
        }
        return true
    }
    
    private fun clearForm() {
        binding.etProductName.text?.clear()
        binding.etPrice.text?.clear()
        binding.etDescription.text?.clear()
        binding.spinnerCategory.setSelection(0)
        selectedImageUri = null
        selectedImageBase64 = null
        binding.btnAddPhoto.text = "Add Photos"
        binding.btnAddPhoto.setBackgroundColor(
            ContextCompat.getColor(requireContext(), android.R.color.holo_green_dark)
        )
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
