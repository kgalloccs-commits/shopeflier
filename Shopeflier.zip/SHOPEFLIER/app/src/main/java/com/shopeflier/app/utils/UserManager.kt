package com.shopeflier.app.utils

import android.content.Context
import android.content.SharedPreferences
import com.shopeflier.app.models.User
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class UserManager(context: Context) {
    
    private val sharedPreferences: SharedPreferences = 
        context.getSharedPreferences("shopeflier_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()
    
    companion object {
        private const val KEY_USERS = "users"
        private const val KEY_CURRENT_USER = "current_user"
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
    }
    
    fun registerUser(user: User): Boolean {
        val users = getAllUsers().toMutableList()
        
        // Check if email already exists
        if (users.any { it.email == user.email }) {
            return false
        }
        
        // Add new user
        users.add(user)
        saveUsers(users)
        
        // Auto login after registration
        loginUser(user.email, user.password)
        
        return true
    }
    
    fun loginUser(email: String, password: String): User? {
        val users = getAllUsers()
        val user = users.find { it.email == email && it.password == password }
        
        if (user != null) {
            // Save current user and login status
            sharedPreferences.edit()
                .putString(KEY_CURRENT_USER, gson.toJson(user))
                .putBoolean(KEY_IS_LOGGED_IN, true)
                .apply()
        }
        
        return user
    }
    
    fun logoutUser() {
        sharedPreferences.edit()
            .remove(KEY_CURRENT_USER)
            .putBoolean(KEY_IS_LOGGED_IN, false)
            .apply()
    }
    
    fun isLoggedIn(): Boolean {
        return sharedPreferences.getBoolean(KEY_IS_LOGGED_IN, false)
    }
    
    fun getCurrentUser(): User? {
        val userJson = sharedPreferences.getString(KEY_CURRENT_USER, null)
        return if (userJson != null) {
            gson.fromJson(userJson, User::class.java)
        } else {
            null
        }
    }
    
    private fun getAllUsers(): List<User> {
        val usersJson = sharedPreferences.getString(KEY_USERS, null)
        return if (usersJson != null) {
            val type = object : TypeToken<List<User>>() {}.type
            gson.fromJson(usersJson, type)
        } else {
            emptyList()
        }
    }
    
    private fun saveUsers(users: List<User>) {
        val usersJson = gson.toJson(users)
        sharedPreferences.edit()
            .putString(KEY_USERS, usersJson)
            .apply()
    }
    
    fun getUserCount(): Int {
        return getAllUsers().size
    }
    
    fun updateUser(updatedUser: User): Boolean {
        val users = getAllUsers().toMutableList()
        val currentUser = getCurrentUser() ?: return false
        
        // Find and update the user
        val index = users.indexOfFirst { it.email == currentUser.email }
        if (index != -1) {
            users[index] = updatedUser
            saveUsers(users)
            
            // Update current user in preferences
            sharedPreferences.edit()
                .putString(KEY_CURRENT_USER, gson.toJson(updatedUser))
                .apply()
            
            return true
        }
        
        return false
    }
}