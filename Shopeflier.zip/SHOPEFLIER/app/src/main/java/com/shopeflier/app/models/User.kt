package com.shopeflier.app.models

data class User(
    val name: String,
    val email: String,
    val phone: String,
    val password: String,
    val registrationDate: Long,
    val profileImage: String? = null,
    val location: String? = null,
    val bio: String? = null
)
