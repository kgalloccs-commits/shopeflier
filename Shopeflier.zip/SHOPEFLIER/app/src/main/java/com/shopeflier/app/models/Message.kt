package com.shopeflier.app.models

data class Message(
    val id: String,
    val senderEmail: String,
    val senderName: String,
    val receiverEmail: String,
    val productId: String?,
    val productTitle: String?,
    val message: String,
    val timestamp: Long,
    val isRead: Boolean = false
)

data class Conversation(
    val otherUserEmail: String,
    val otherUserName: String,
    val lastMessage: String,
    val lastMessageTime: Long,
    val unreadCount: Int,
    val productTitle: String?
)
