package com.shopeflier.app.utils

import android.content.Context
import android.content.SharedPreferences
import com.shopeflier.app.models.Product
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.UUID

class ProductManager(context: Context) {
    
    private val sharedPreferences: SharedPreferences = 
        context.getSharedPreferences("shopeflier_products", Context.MODE_PRIVATE)
    private val gson = Gson()
    
    companion object {
        private const val KEY_PRODUCTS = "products"
    }
    
    init {
        // Add sample products if none exist
        if (getAllProducts().isEmpty()) {
            addSampleProducts()
        }
    }
    
    fun addProduct(product: Product): Boolean {
        val products = getAllProducts().toMutableList()
        products.add(product)
        saveProducts(products)
        return true
    }
    
    fun getAllProducts(): List<Product> {
        val productsJson = sharedPreferences.getString(KEY_PRODUCTS, null)
        return if (productsJson != null) {
            val type = object : TypeToken<List<Product>>() {}.type
            gson.fromJson(productsJson, type)
        } else {
            emptyList()
        }
    }
    
    fun getFeaturedProducts(): List<Product> {
        return getAllProducts().filter { it.isFeatured }.take(5)
    }
    
    fun getProductsByCategory(category: String): List<Product> {
        return getAllProducts().filter { it.category == category }
    }
    
    fun getProductsBySeller(sellerEmail: String): List<Product> {
        return getAllProducts().filter { it.sellerEmail == sellerEmail }
    }
    
    fun searchProducts(query: String): List<Product> {
        val lowerQuery = query.lowercase()
        return getAllProducts().filter {
            it.title.lowercase().contains(lowerQuery) ||
            it.description.lowercase().contains(lowerQuery) ||
            it.category.lowercase().contains(lowerQuery)
        }
    }
    
    fun deleteProduct(productId: String): Boolean {
        val products = getAllProducts().toMutableList()
        val removed = products.removeIf { it.id == productId }
        if (removed) {
            saveProducts(products)
        }
        return removed
    }
    
    private fun saveProducts(products: List<Product>) {
        val productsJson = gson.toJson(products)
        sharedPreferences.edit()
            .putString(KEY_PRODUCTS, productsJson)
            .apply()
    }
    
    private fun addSampleProducts() {
        val sampleProducts = listOf(
            Product(
                id = UUID.randomUUID().toString(),
                title = "iPhone 13 Pro",
                description = "Excellent condition, 256GB, Pacific Blue. Includes original box and accessories.",
                price = 899.99,
                category = "Electronics",
                condition = "Like New",
                imageUrl = null,
                sellerEmail = "demo@shopeflier.com",
                sellerName = "Demo Seller",
                location = "New York, NY",
                postedDate = System.currentTimeMillis() - 86400000,
                isFeatured = true
            ),
            Product(
                id = UUID.randomUUID().toString(),
                title = "MacBook Air M2",
                description = "2023 model, 16GB RAM, 512GB SSD. Perfect for students and professionals.",
                price = 1199.99,
                category = "Electronics",
                condition = "New",
                imageUrl = null,
                sellerEmail = "demo@shopeflier.com",
                sellerName = "Demo Seller",
                location = "San Francisco, CA",
                postedDate = System.currentTimeMillis() - 172800000,
                isFeatured = true
            ),
            Product(
                id = UUID.randomUUID().toString(),
                title = "Vintage Leather Sofa",
                description = "Beautiful brown leather 3-seater sofa. Minor wear, very comfortable.",
                price = 450.00,
                category = "Furniture",
                condition = "Good",
                imageUrl = null,
                sellerEmail = "demo@shopeflier.com",
                sellerName = "Demo Seller",
                location = "Los Angeles, CA",
                postedDate = System.currentTimeMillis() - 259200000,
                isFeatured = false
            ),
            Product(
                id = UUID.randomUUID().toString(),
                title = "Mountain Bike - Trek X-Caliber",
                description = "29-inch wheels, 21-speed, aluminum frame. Great for trails!",
                price = 650.00,
                category = "Sports",
                condition = "Good",
                imageUrl = null,
                sellerEmail = "demo@shopeflier.com",
                sellerName = "Demo Seller",
                location = "Denver, CO",
                postedDate = System.currentTimeMillis() - 345600000,
                isFeatured = true
            ),
            Product(
                id = UUID.randomUUID().toString(),
                title = "Designer Handbag - Michael Kors",
                description = "Authentic MK handbag, black leather, barely used. Comes with dust bag.",
                price = 180.00,
                category = "Fashion",
                condition = "Like New",
                imageUrl = null,
                sellerEmail = "demo@shopeflier.com",
                sellerName = "Demo Seller",
                location = "Miami, FL",
                postedDate = System.currentTimeMillis() - 432000000,
                isFeatured = false
            )
        )
        
        saveProducts(sampleProducts)
    }
    
    fun getCategories(): List<String> {
        return listOf(
            "Electronics",
            "Furniture",
            "Fashion",
            "Sports",
            "Books",
            "Home & Garden",
            "Toys & Games",
            "Automotive",
            "Other"
        )
    }
}
