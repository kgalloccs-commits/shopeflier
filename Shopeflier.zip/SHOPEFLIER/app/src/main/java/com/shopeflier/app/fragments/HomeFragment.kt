package com.shopeflier.app.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.shopeflier.app.databinding.FragmentHomeBinding
import com.shopeflier.app.utils.UserManager

class HomeFragment : Fragment() {
    
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private lateinit var userManager: UserManager
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        userManager = UserManager(requireContext())
        setupUI()
    }
    
    private fun setupUI() {
        val currentUser = userManager.getCurrentUser()
        currentUser?.let {
            binding.tvWelcome.text = "Welcome back, ${it.name}!"
            binding.tvSubtitle.text = "Discover amazing deals today"
        }
        
        // Set up quick stats
        val productManager = com.shopeflier.app.utils.ProductManager(requireContext())
        val messageManager = com.shopeflier.app.utils.MessageManager(requireContext())
        
        val userProducts = productManager.getProductsBySeller(currentUser?.email ?: "")
        val unreadMessages = messageManager.getUnreadMessageCount(currentUser?.email ?: "")
        
        binding.tvItemsListed.text = "${userProducts.size}"
        binding.tvTransactions.text = "0" 
        binding.tvMessages.text = "$unreadMessages"
        
        // Set up clickable stat cards
        binding.cardItemsListed.setOnClickListener {
            navigateToMyListings()
        }
        
        binding.cardTransactions.setOnClickListener {
            navigateToTransactions()
        }
        
        binding.cardMessages.setOnClickListener {
            navigateToMessages()
        }
        
        // Set up quick action buttons
        binding.btnBrowseProducts.setOnClickListener {
            navigateToBrowse()
        }
        
        binding.btnSellItem.setOnClickListener {
            navigateToSell()
        }
    }
    
    private fun navigateToMyListings() {
        // Navigate to Profile tab to see user's listings
        (activity as? com.shopeflier.app.DashboardActivity)?.let { dashboardActivity ->
            dashboardActivity.findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(
                com.shopeflier.app.R.id.bottom_navigation
            )?.selectedItemId = com.shopeflier.app.R.id.nav_profile
        }
    }
    
    private fun navigateToTransactions() {
        // For now, show a message about transactions
        android.widget.Toast.makeText(
            requireContext(), 
            "Transactions feature coming soon!\nThis will show your purchase and sale history.", 
            android.widget.Toast.LENGTH_LONG
        ).show()
    }
    
    private fun navigateToMessages() {
        // Navigate to Messages tab
        (activity as? com.shopeflier.app.DashboardActivity)?.let { dashboardActivity ->
            dashboardActivity.findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(
                com.shopeflier.app.R.id.bottom_navigation
            )?.selectedItemId = com.shopeflier.app.R.id.nav_messages
        }
    }
    
    private fun navigateToBrowse() {
        // Navigate to Browse tab
        (activity as? com.shopeflier.app.DashboardActivity)?.let { dashboardActivity ->
            dashboardActivity.findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(
                com.shopeflier.app.R.id.bottom_navigation
            )?.selectedItemId = com.shopeflier.app.R.id.nav_browse
        }
    }
    
    private fun navigateToSell() {
        // Navigate to Sell tab
        (activity as? com.shopeflier.app.DashboardActivity)?.let { dashboardActivity ->
            dashboardActivity.findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(
                com.shopeflier.app.R.id.bottom_navigation
            )?.selectedItemId = com.shopeflier.app.R.id.nav_sell
        }
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}