package com.shopeflier.app

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.shopeflier.app.databinding.ActivityProductDetailBinding
import com.shopeflier.app.models.Product
import com.shopeflier.app.utils.ImageHelper
import com.shopeflier.app.utils.MessageManager
import com.shopeflier.app.utils.ProductManager
import com.shopeflier.app.utils.UserManager

class ProductDetailActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityProductDetailBinding
    private lateinit var productManager: ProductManager
    private lateinit var messageManager: MessageManager
    private lateinit var userManager: UserManager
    private var product: Product? = null
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProductDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        productManager = ProductManager(this)
        messageManager = MessageManager(this)
        userManager = UserManager(this)
        
        val productId = intent.getStringExtra("PRODUCT_ID")
        if (productId != null) {
            loadProduct(productId)
        } else {
            finish()
        }
        
        setupUI()
    }
    
    private fun setupUI() {
        binding.btnBack.setOnClickListener {
            finish()
        }
        
        binding.btnChatSeller.setOnClickListener {
            chatWithSeller()
        }
        
        binding.btnFavorite.setOnClickListener {
            toggleFavorite()
        }
        
        binding.btnShare.setOnClickListener {
            shareProduct()
        }
    }
    
    private fun loadProduct(productId: String) {
        product = productManager.getAllProducts().find { it.id == productId }
        
        product?.let { prod ->
            displayProduct(prod)
        } ?: run {
            Toast.makeText(this, "Product not found", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
    
    private fun displayProduct(product: Product) {
        binding.tvTitle.text = product.title
        binding.tvPrice.text = "₱${String.format("%.2f", product.price)}"
        binding.tvDescription.text = product.description
        binding.tvCategory.text = product.category
        binding.tvCondition.text = product.condition
        binding.tvLocation.text = product.location
        binding.tvSellerName.text = product.sellerName
        binding.tvPostedDate.text = "Posted ${formatDate(product.postedDate)}"
        
        // Load product image if available
        if (product.imageUrl != null) {
            ImageHelper.loadBase64Image(binding.ivProductImage, product.imageUrl)
            binding.ivProductImage.visibility = android.view.View.VISIBLE
        } else {
            binding.ivProductImage.visibility = android.view.View.GONE
        }
        
        // Check if current user is the seller
        val currentUser = userManager.getCurrentUser()
        if (currentUser?.email == product.sellerEmail) {
            binding.btnChatSeller.text = "This is your listing"
            binding.btnChatSeller.isEnabled = false
        } else {
            binding.btnChatSeller.text = "Chat with ${product.sellerName}"
            binding.btnChatSeller.isEnabled = true
        }
    }
    
    private fun chatWithSeller() {
        val currentUser = userManager.getCurrentUser()
        if (currentUser == null) {
            Toast.makeText(this, "Please log in to chat with seller", Toast.LENGTH_SHORT).show()
            return
        }
        
        product?.let { prod ->
            if (currentUser.email == prod.sellerEmail) {
                Toast.makeText(this, "You cannot chat with yourself", Toast.LENGTH_SHORT).show()
                return
            }
            
            val intent = Intent(this, ChatActivity::class.java).apply {
                putExtra("OTHER_USER_EMAIL", prod.sellerEmail)
                putExtra("OTHER_USER_NAME", prod.sellerName)
                putExtra("PRODUCT_ID", prod.id)
                putExtra("PRODUCT_TITLE", prod.title)
            }
            startActivity(intent)
        }
    }
    
    private fun toggleFavorite() {
        // TODO: Implement favorite functionality
        Toast.makeText(this, "Favorite feature coming soon!", Toast.LENGTH_SHORT).show()
    }
    
    private fun shareProduct() {
        product?.let { prod ->
            val shareText = """
                Check out this item on Shopeflier!
                
                ${prod.title}
                ₱${String.format("%.2f", prod.price)}
                
                ${prod.description}
                
                Location: ${prod.location}
                Condition: ${prod.condition}
                
                Contact ${prod.sellerName} to buy this item!
            """.trimIndent()
            
            val shareIntent = Intent().apply {
                action = Intent.ACTION_SEND
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, shareText)
                putExtra(Intent.EXTRA_SUBJECT, "Check out: ${prod.title}")
            }
            
            startActivity(Intent.createChooser(shareIntent, "Share Product"))
        }
    }
    
    private fun formatDate(timestamp: Long): String {
        val now = System.currentTimeMillis()
        val diff = now - timestamp
        
        return when {
            diff < 86400000 -> "today"
            diff < 172800000 -> "yesterday"
            diff < 604800000 -> "${diff / 86400000} days ago"
            else -> {
                val date = java.util.Date(timestamp)
                val format = java.text.SimpleDateFormat("MMM dd, yyyy", java.util.Locale.getDefault())
                format.format(date)
            }
        }
    }
}