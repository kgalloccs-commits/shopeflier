package com.shopeflier.app.utils

import android.content.Context
import android.content.SharedPreferences
import com.shopeflier.app.models.Message
import com.shopeflier.app.models.Conversation
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.UUID

class MessageManager(context: Context) {
    
    private val sharedPreferences: SharedPreferences = 
        context.getSharedPreferences("shopeflier_messages", Context.MODE_PRIVATE)
    private val gson = Gson()
    
    companion object {
        private const val KEY_MESSAGES = "messages"
        private const val KEY_CONVERSATIONS = "conversations"
    }
    
    fun sendMessage(
        senderEmail: String,
        senderName: String,
        receiverEmail: String,
        productId: String?,
        productTitle: String?,
        messageText: String
    ): Message {
        val message = Message(
            id = UUID.randomUUID().toString(),
            senderEmail = senderEmail,
            senderName = senderName,
            receiverEmail = receiverEmail,
            productId = productId,
            productTitle = productTitle,
            message = messageText,
            timestamp = System.currentTimeMillis(),
            isRead = false
        )
        
        val messages = getAllMessages().toMutableList()
        messages.add(message)
        saveMessages(messages)
        
        updateConversation(message)
        
        return message
    }
    
    fun getAllMessages(): List<Message> {
        val messagesJson = sharedPreferences.getString(KEY_MESSAGES, null)
        return if (messagesJson != null) {
            val type = object : TypeToken<List<Message>>() {}.type
            gson.fromJson(messagesJson, type)
        } else {
            emptyList()
        }
    }
    
    fun getConversationsForUser(userEmail: String): List<Conversation> {
        val messages = getAllMessages()
        val conversationMap = mutableMapOf<String, MutableList<Message>>()
        
        // Group messages by conversation partner
        messages.forEach { message ->
            val otherUser = if (message.senderEmail == userEmail) {
                message.receiverEmail
            } else if (message.receiverEmail == userEmail) {
                message.senderEmail
            } else {
                return@forEach
            }
            
            if (!conversationMap.containsKey(otherUser)) {
                conversationMap[otherUser] = mutableListOf()
            }
            conversationMap[otherUser]?.add(message)
        }
        
        // Convert to Conversation objects
        return conversationMap.map { (otherUserEmail, messageList) ->
            val sortedMessages = messageList.sortedByDescending { it.timestamp }
            val lastMessage = sortedMessages.first()
            val unreadCount = messageList.count { 
                !it.isRead && it.receiverEmail == userEmail 
            }
            
            val otherUserName = if (lastMessage.senderEmail == userEmail) {
                "You" // This will be replaced with actual receiver name
            } else {
                lastMessage.senderName
            }
            
            Conversation(
                otherUserEmail = otherUserEmail,
                otherUserName = otherUserName,
                lastMessage = lastMessage.message,
                lastMessageTime = lastMessage.timestamp,
                unreadCount = unreadCount,
                productTitle = lastMessage.productTitle
            )
        }.sortedByDescending { it.lastMessageTime }
    }
    
    fun getMessagesForConversation(userEmail: String, otherUserEmail: String): List<Message> {
        return getAllMessages().filter { message ->
            (message.senderEmail == userEmail && message.receiverEmail == otherUserEmail) ||
            (message.senderEmail == otherUserEmail && message.receiverEmail == userEmail)
        }.sortedBy { it.timestamp }
    }
    
    fun markMessagesAsRead(userEmail: String, otherUserEmail: String) {
        val messages = getAllMessages().toMutableList()
        var hasChanges = false
        
        messages.forEachIndexed { index, message ->
            if (message.senderEmail == otherUserEmail && 
                message.receiverEmail == userEmail && 
                !message.isRead) {
                messages[index] = message.copy(isRead = true)
                hasChanges = true
            }
        }
        
        if (hasChanges) {
            saveMessages(messages)
        }
    }
    
    fun getUnreadMessageCount(userEmail: String): Int {
        return getAllMessages().count { 
            it.receiverEmail == userEmail && !it.isRead 
        }
    }
    
    private fun updateConversation(message: Message) {
        // This method can be used to update conversation metadata if needed
        // For now, conversations are generated dynamically from messages
    }
    
    private fun saveMessages(messages: List<Message>) {
        val messagesJson = gson.toJson(messages)
        sharedPreferences.edit()
            .putString(KEY_MESSAGES, messagesJson)
            .apply()
    }
    
    // Sample data for demonstration
    fun addSampleMessages(currentUserEmail: String) {
        if (getAllMessages().isEmpty()) {
            val sampleMessages = listOf(
                Message(
                    id = UUID.randomUUID().toString(),
                    senderEmail = "demo@shopeflier.com",
                    senderName = "Demo Seller",
                    receiverEmail = currentUserEmail,
                    productId = "sample-product-1",
                    productTitle = "iPhone 13 Pro",
                    message = "Hi! Is this iPhone still available?",
                    timestamp = System.currentTimeMillis() - 3600000, // 1 hour ago
                    isRead = false
                ),
                Message(
                    id = UUID.randomUUID().toString(),
                    senderEmail = currentUserEmail,
                    senderName = "You",
                    receiverEmail = "demo@shopeflier.com",
                    productId = "sample-product-1",
                    productTitle = "iPhone 13 Pro",
                    message = "Yes, it's still available! Are you interested?",
                    timestamp = System.currentTimeMillis() - 3300000, // 55 minutes ago
                    isRead = true
                ),
                Message(
                    id = UUID.randomUUID().toString(),
                    senderEmail = "demo@shopeflier.com",
                    senderName = "Demo Seller",
                    receiverEmail = currentUserEmail,
                    productId = "sample-product-1",
                    productTitle = "iPhone 13 Pro",
                    message = "Great! Can we meet tomorrow at 2 PM?",
                    timestamp = System.currentTimeMillis() - 1800000, // 30 minutes ago
                    isRead = false
                )
            )
            
            saveMessages(sampleMessages)
        }
    }
}