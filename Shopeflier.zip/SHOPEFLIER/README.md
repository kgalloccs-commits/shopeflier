# Shopeflier - Online Trading Marketplace

Shopeflier is an Android application designed to connect buyers, sellers, and traders in one platform. It allows users to post, browse, and negotiate items for sale or trade, making it easier to find good deals or exchange products.

## Features Implemented

### ✅ Authentication System
- **Login Form**: Email and password authentication
- **Registration Form**: Full name, email, phone, password, and confirm password
- **Input Validation**: Comprehensive error handling for missing or invalid inputs
- **Multiple User Support**: Users are saved to SharedPreferences with support for multiple registrations
- **Error Handling**: Pop-up errors for incorrect login credentials and validation failures

### ✅ Dashboard System
- **Home Fragment**: Welcome screen with quick stats and actions
- **Browse Fragment**: Product search and category filtering
- **Sell Fragment**: Item listing form with categories and pricing
- **Messages Fragment**: Placeholder for future messaging system
- **Profile Fragment**: User profile information and account settings
- **Bottom Navigation**: Easy navigation between all sections

### ✅ User Management
- **Logout Functionality**: Secure logout with session management
- **User Session**: Persistent login state using SharedPreferences
- **Profile Display**: Shows user information from registration

## Technical Implementation

### Architecture
- **MVVM Pattern**: Clean separation of concerns
- **Fragment-based Navigation**: Modern Android navigation patterns
- **Material Design**: Google's Material Design components
- **SharedPreferences**: Local data persistence for user management

### Key Components
- `MainActivity`: Handles login/registration
- `DashboardActivity`: Main app container with bottom navigation
- `UserManager`: Handles all user-related operations and data persistence
- `User` data class: User model with serialization support
- Fragment system for different app sections

### Data Storage
- User data is stored locally using SharedPreferences
- JSON serialization with Gson for complex data structures
- Support for multiple user accounts
- Persistent login sessions

## Project Structure
```
app/
├── src/main/
│   ├── java/com/shopeflier/app/
│   │   ├── MainActivity.kt              # Login/Registration
│   │   ├── DashboardActivity.kt         # Main dashboard
│   │   ├── models/User.kt               # User data model
│   │   ├── utils/UserManager.kt         # User management
│   │   └── fragments/                   # Dashboard fragments
│   │       ├── HomeFragment.kt
│   │       ├── BrowseFragment.kt
│   │       ├── SellFragment.kt
│   │       ├── MessagesFragment.kt
│   │       └── ProfileFragment.kt
│   └── res/
│       ├── layout/                      # XML layouts
│       ├── values/                      # Colors, strings, themes
│       ├── drawable/                    # Icons and backgrounds
│       └── menu/                        # Navigation menu
```

## Setup Instructions

1. **Import to Android Studio**:
   - Open Android Studio
   - Select "Open an existing project"
   - Navigate to the project folder and select it

2. **Build the Project**:
   - Let Android Studio sync the Gradle files
   - Build the project (Build → Make Project)

3. **Run the Application**:
   - Connect an Android device or start an emulator
   - Click the "Run" button or press Shift+F10

## Requirements
- **Minimum SDK**: Android 7.0 (API level 24)
- **Target SDK**: Android 14 (API level 34)
- **Kotlin**: 1.9.10
- **Android Gradle Plugin**: 8.2.0

## Dependencies
- AndroidX Core KTX
- AppCompat
- Material Design Components
- ConstraintLayout
- Navigation Components
- Lifecycle Components
- Fragment KTX
- Gson for JSON serialization

## Future Enhancements
- Real-time messaging system
- Product image upload and display
- Advanced search and filtering
- User ratings and reviews
- Push notifications
- Payment integration
- Admin panel functionality

## Screenshots
The app includes:
- Clean, modern login/registration interface
- Intuitive dashboard with bottom navigation
- Professional-looking forms and layouts
- Material Design components throughout
- Responsive design for different screen sizes

## Author
**Ken Anthony I. Gallo**  
BSCS - 3CS413-SE2 SOFTWARE ENGINEERING

---

This project demonstrates a complete Android application with user authentication, data persistence, and a modern UI following Android development best practices.